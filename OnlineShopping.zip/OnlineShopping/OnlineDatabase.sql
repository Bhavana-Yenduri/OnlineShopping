﻿create table prod_category
(
categoryid int primary key,
categoryname varchar(30)
);

insert into prod_category values(1,'Clothing')
insert into prod_category values(2,'Electronics')
insert into prod_category values(3,'Bags')
insert into prod_category values(4,'Home Appliances')

select * from prod_category

create table product
(
id int primary key,
categoryid int references prod_category(categoryid),
pname varchar(max),
picture varchar(20),
price decimal,
description nvarchar(max),
Quantity int
)

insert into product values(1,1,'Funday fashion full sleeve blue solid women Denim Jacket','c1.jpg',449.00,'Color:Light Blue,Size:L',1)
insert into product values(2,1,'Montrez Women Solid Denim Jacket','c2.jpg',379.00,'Size:M,Color:Black',1)
insert into product values(3,1,' Generic Women Tops','c3.jpg',399.00,'Color:Red,Size:XL',1)
insert into product values(4,1,' long round necked Tops without sleeves','c4.jpg',764.00,'Color:Black and White,Size:XL',1)
insert into product values(5,2,' One plus 8 pro Mobile','m1.jpg',54999.00,'Brand:OnePlus,Style Name: 8GB RAM + 12GB storage,Color:Onyx Black',1)
insert into product values(6,2,' MI 10i 5G Mobile','m2.jpg',23999.00,'Brand:Mi,Style Name:8GB RAM +128GB storage,color:Atlantic Blue',1)
insert into product values(7,2,' Samsung Galaxy S21 Plus 5G Mobile','m3.jpg',81999.00,'Brand:Samsung,Color:Phantom Silver,Style Name:8GB RAM+128GB storage',1)
insert into product values(8,2,' Dell Laptop','l1.jpg',195790.00,'Brand:Dell,Style Name:core i7,Color:Silver',1)
insert into product values(9,2,' Lenovo ideaPad S340 10th Gen Laptop','l2.jpg',52974.00,'Brand: Lenovo,Style Name:81VV00KKIN-IdeaPad-S340,Color:Silver',1)
insert into product values(10,3,' Girls Phone Holder Pocket wallet cross Body Sling Bag','b1.jpg',599.00,'Color:Pink,Brand:MOCA',1)
insert into product values(11,3,' The Purple Tree Women Sling Bag','b2.jpg',649.00,'Brand:Purple Tree,Color:RB10',1)
insert into product values(12,4,' Amazon Basics 564L Frost Free Side-by-side Refrigerator','r1.jpg',43225.00,'Brand:AmazonBasics,Style Name:564L,Color:Silver',1)
insert into product values(13,4,' Whirlpool 265L 3 Star Inverter Double door Refrigerator','r2.jpg',20000.00,'Brand:WhirlPool,Color:Germen Steel',1)
insert into product values(14,4,' Blue Star 1.5 Ton 5 Star Inverter Split Air Conditioner','a1.jpg',35999.00,'Brand:Blue Star',1)
insert into product values(15,4,' LG 1 Ton 5 Star Inverter Split Air Conditioner','a2.jpg',29999.00,'Brand:LG',1)
insert into product values(16,4,' SkyTone Mini Folding Washing Machine','w1.jpg',4499.00,'Brand:Skytone,Color:white',1)

select * from product

create table cartItems
(
id int references product(id),
pname varchar(max),
picture varchar(20),
price decimal,
description nvarchar(max),
Quantity int
)

select * from cartItems


create table login_details
(
username varchar(20),
password varchar(20)
)

insert into login_details values('Bhavana','abcd')
insert into login_details values('Siri','abc')
insert into login_details values('satya','abcde')
insert into login_details values('Rama','xyz')

select * from login_details

