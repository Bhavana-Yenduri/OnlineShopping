﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineShopping.Models
{
    public class Login_Details
    {
        [Required(ErrorMessage="UserName must not be empty")]
        [StringLength(15,MinimumLength =3,ErrorMessage ="UserName must be between 3 and 15 characters")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Password  must not be empty")]
        [StringLength(15, MinimumLength = 3, ErrorMessage = "Password must be between 3 and 15 characters")]
        public string Password { get; set; }
        
    }
}