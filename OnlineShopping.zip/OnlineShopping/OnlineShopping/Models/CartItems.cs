﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShopping.Models
{
    public class CartItems
    {
        public int ProductId { get; set; }
        //public int CategoryId { get; set; }
        public string ProductName { get; set; }
        public string Picture { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public string DisplayDescription()
        {
            string data = null;
            string[] cols = Description.Split(',');
            foreach (var item in cols)
            {
                string colName, colValue;
                string[] col = item.Split(':');
                colName = col[0];
                colValue = col[1];
                data += "<b>" + colName + "</b>" + ":" + colValue + "<br/>";
            }
            return data;
        }
    }
}