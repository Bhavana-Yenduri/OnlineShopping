﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;

namespace OnlineShopping.Controllers
{
    public class OnlineShopingController : Controller
    {
       
        // GET: OnlineShoping
        [HttpGet]
        public ActionResult Home()
        {
            //localtest connection of API
            Uri uri = new Uri("http://localhost:53481/api/");
            //call API for GET
            using (var client = new HttpClient())
            {
                //sets the base address defines the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopingWeb").Result;
                //gets the list of categories
                var lst = JsonConvert.DeserializeObject<List<Category>>(result);
                //returns the list of categories to "Index" view to display
                return View(lst);
            }
        }
        [HttpPost]
        public ActionResult DisplayProductsByName(string Name)
        {
            //localhostconnection of API
            Uri uri = new Uri("http://localhost:53481/api/");
            //call API for GET
            using (var client = new HttpClient())
            {
                //set a the base address defines the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopingWeb/GetProductsByName/" + Name).Result;
                //get the product list by name
                var lst = JsonConvert.DeserializeObject<List<Product>>(result);
                //returns the list of products to display product by name
                return View(lst);
            }
        }
        
        [HttpGet]
        public ActionResult DisplayProductsByCategory(string Name)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:53481/api/");
            //call API for GET
            using (var client = new HttpClient())
            {
                //set a base address definrs the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopingWeb/GetProductsByCategory/" + Name).Result;
                //get the product list by category
                var lst = JsonConvert.DeserializeObject<List<Product>>(result);
                //returns the list of products to display products by category
                return View(lst);
            }
        }

        [HttpGet]
        public ActionResult DisplayProductDetailsById(int id)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:53481/api/");
            //call API for GET
            using (var client = new HttpClient())
            {
                //set a base address defines the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopingWeb/GetProductDetailsById/" + id).Result;
                //get the product details by prdoduct id
                var pro = JsonConvert.DeserializeObject<Product>(result);
                //returns the product details to display products by product id
                return View(pro);
            }
        }
        [HttpGet]
        public ActionResult AddToCart()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddToCart(CartItems item)
        {
            //if condition is satisfied then it is added to cart
            if(Session["cart"]==null)
            {
                var cartList = new List<CartItems>();
                cartList.Add(item);
                Session.Add("cart", cartList);
            }
            //else this condition will be executed
            else
            {
                var cartList = (List<CartItems>)Session["cart"];
                cartList.Add(item);
                Session.Add("cart", cartList);
            }
            //after adding to cart, it will be redirected to home page view
            return RedirectToAction("Home");
        }
        
        public ActionResult DisplayCart()
        {
            //the items that are added to cart are displayed here in this view
            var cartLst = (List<CartItems>)Session["cart"];
            Session.Add("cartList", cartLst);
            return View(cartLst);
        }
       
        public ActionResult PostToCart()
        {
            //localhost connection for api
            Uri uri = new Uri("http://localhost:53481/api/");
            var cartLst = (List<CartItems>)Session["cart"];
            //call API for Post
            using (var client = new HttpClient())
            {
                //set a base address defines the uri path
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync<List<CartItems>>("OnlineShopingWeb/AddToCart/", cartLst).Result;
                //if posting to cart is success
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Product List Posted Successfully");
                }
                //if posting to cart is failure
                else
                {
                    ViewData.Add("msg", "Not Successfull!!!");
                }
            }
            return View(cartLst);
        }
      
        public ActionResult GetListFromCart()
        {
            //localhost connection for api
            Uri uri = new Uri("http://localhost:53481/api/");
            //call API for post
            using (var client = new HttpClient())
            {
                //set a base address defines the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopingWeb/GetListFromCart/").Result;
                //get the cart item details from the database
                var lst = JsonConvert.DeserializeObject<List<CartItems>>(result);
                //returns the cart list fromthe database
                return View(lst);
            }
        }
       
        public ActionResult Delete(int id)
        {
            //this method deletes the cart item based on product id
            var cartLst = (List<CartItems>)Session["cartList"];
            var prodct = cartLst.Where(o => o.ProductId == id).FirstOrDefault();
            cartLst.Remove(prodct);
            Session["cart"] = cartLst;
            //after the deletion successful it will be redirect to home page view
            return RedirectToAction("Home");
        }
       
        public ActionResult DeleteOrder(int id)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:53481/api/");
            
            using (var client = new HttpClient())
            {
                //setsthe base address defines the uri path
                client.BaseAddress = uri;
                var result = client.DeleteAsync("OnlineShopingWeb/" + id).Result;
                //if deleting from cart is success
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Record deleted successfully");
                }
                //if deleting from cart is not success
                else
                {
                    ViewData.Add("msg", "Could not delete record, some error");
                }
                //After successfull deletion it will redirect to home page view
                return RedirectToAction("Home");
            }

        }
        [HttpGet]
        public ActionResult UpdateCartById(int id)
        {
            //updates the quantity of the product
            var cartItemsLst = (List<CartItems>)Session["cart"];
            var cartItem = cartItemsLst.Where(o => o.ProductId == id).FirstOrDefault();
            //updates and return to the same view
            return View(cartItem);
        }
        [HttpPost]
        public ActionResult UpdateCartById(CartItems cartList)
        {
            var cartItemsLst = (List<CartItems>)Session["cart"];
            var cartItem = cartItemsLst.Where(o => o.ProductId == cartList.ProductId).FirstOrDefault();
            cartItem.Quantity = cartList.Quantity;
            Session["cart"] = cartItemsLst;
            return RedirectToAction("DisplayCart");
        }

        [Authorize]
        [HttpGet]
        public ActionResult  PlaceOrder()
        {
            var cartLst=(List<CartItems>)Session["cart"];
            cartLst.Clear();
            Session["cart"]=cartLst;
            return View();
        }




    }

}