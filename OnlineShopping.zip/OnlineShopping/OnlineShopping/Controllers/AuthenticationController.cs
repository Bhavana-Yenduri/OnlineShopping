﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using OnlineShopping.Models;
using System.Web.Security;

namespace OnlineShopping.Controllers
{
    public class AuthenticationController : Controller
    {
        // GET: Authentication
        /// <summary>
        /// This action is used to go to view of login and post the login details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login_Details login)
        {
            Uri uri = new Uri("http://localhost:53481/api/");
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                var uname = client.GetStringAsync("AuthenticationWeb/GetUserName/" + login.UserName).Result;
                var name = JsonConvert.DeserializeObject<Login_Details>(uname);
                string username = name.UserName;
                var pswd = client.GetStringAsync("AuthenticationWeb/GetPassword/" + login.Password).Result;
                var pwd = JsonConvert.DeserializeObject<Login_Details>(pswd);
                string password = pwd.Password;
                if((login.UserName.Equals(username))&&(login.Password.Equals(password)))
                {
                    FormsAuthentication.SetAuthCookie(login.UserName, false);
                    var returnUrl = Request.Form["returnUrl"];
                    return Redirect(returnUrl);
                }
                else
                {
                    ModelState.AddModelError("UserName", "UserName and Password are invalid,Please try with another credentials");
                }
                var returnUrl1 = Request.QueryString.Get("returnUrl");
                ViewData.Add("returnUrl", returnUrl1);
                return View();
            }               
        }
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View();
        }
    }
}