﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopingEntityLayer
{
    /// <summary>
    /// Products class
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Product Id
        /// </summary>
        public int ProductId { get; set; }
        /// <summary>
        /// Category Id
        /// </summary>
        public int CategoryId { get; set; }
        /// <summary>
        /// Product Name(Name of the product)
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Picture (image of the product)
        /// </summary>
        public string Picture { get; set; }
        /// <summary>
        /// Price (Price of the product)
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// Description (Details of the product)
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Quantity 
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// This method is used for displaying the description of products.
        /// So that Every column value will be in each row. This will happen using Split operator.
        /// </summary>
        /// <returns></returns>
        public string DisplayDescription()
        {
            string data = null;
            string[] cols = Description.Split(',');
            foreach (var item in cols)
            {
                string colName, colValue;
                string[] col = item.Split(':');
                colName = col[0];
                colValue = col[1];
                data += "<b>" + colName + "</b>" + ":" + colValue + "<br/>";
            }
            return data;
        }
    }
}
