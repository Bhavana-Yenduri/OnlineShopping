﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopingEntityLayer
{
    public class Login_Details
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Emailid { get; set; }
        public string Confirm_password { get; set; }
    }
}
