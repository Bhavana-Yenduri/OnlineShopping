﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShopingEntityLayer;
using OnlineShopingBusinessLayer;
using OnlineShopingExceptionLayer;

namespace OnlineShoppingWeb.Controllers
{
    public class OnlineShopingWebController : ApiController
    {
        /// <summary>
        /// This method is to retrieve products list by name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>products list</returns>
        [Route("api/OnlineShopingWeb/GetProductsByName/{Name}")]
        public  HttpResponseMessage GetProductsByName(string Name)
        {
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK,"List of products are found");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                var lst = bll.GetProductsByName(Name);
                httpResponseMessage = Request.CreateResponse<List<Product>>(lst);
            }
            catch(OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch(Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound,"Products are not found");
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// This method is to retrieve products list by category
        /// </summary>
        /// <param name="name"></param>
        /// <returns>product list</returns>
        [Route("api/OnlineShopingWeb/GetProductsByCategory/{name}")]
        public HttpResponseMessage GetProductsByCategory(string name)
        {
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, "List of products are found");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                var lst = bll.GetProductsByCategory(name);
                httpResponseMessage = Request.CreateResponse<List<Product>>(lst);
            }
            catch (OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch(Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, "Products are not found");
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// This method is to retrieve categories from database
        /// </summary>
        /// <returns>categories list</returns>
        public HttpResponseMessage Get()
        {
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                var category = bll.GetAllCategories();
                httpResponseMessage = Request.CreateResponse<List<Category>>(category);
            }
            catch (OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch(Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, "Category was not found");
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// This method is to retrieve the product details by id
        /// </summary>
        /// <param name="id">iproduct id is passed</param>
        /// <returns>product details is retrieved</returns>
        [Route("api/OnlineShopingWeb/GetProductDetailsById/{id}")]
        public HttpResponseMessage GetProductDetailsById(int id)
        {
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, "Product details are found");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                var lst = bll.GetProductDetailsById(id);
                httpResponseMessage = Request.CreateResponse<Product>(lst);
            }
            catch (OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, "product was not found");
            }
            return httpResponseMessage;

        }

        /// <summary>
        /// This method is used to post the product details to the cart
        /// </summary>
        /// <param name="cartList">cartlist is passed</param>
        /// <returns>cartlist</returns>
        [Route("api/OnlineShopingWeb/AddToCart/")]
        public HttpResponseMessage Post([FromBody] List<CartItems> cartList)
        {
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Added to Cart");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                bll.AddToCart(cartList);
            }
            catch(OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// This method is used to get list from cart
        /// </summary>
        /// <returns>list of products from database</returns>
        [Route("api/OnlineShopingWeb/GetListFromCart")]
        public HttpResponseMessage GetListFromCart()
        {
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, "Product details are found");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                var cartlst = bll.GetListFromCart();
                httpResponseMessage = Request.CreateResponse<List<CartItems>>(cartlst);
            }
            catch (OnlineShopingException ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, "product was not found");
            }
            return httpResponseMessage;
           
        }

        /// <summary>
        /// used to delete the product from database
        /// </summary>
        /// <param name="id"></param>
        /// <returns>record will be deleted</returns>
        public HttpResponseMessage Delete(int id)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "order was cancelled");
            try
            {
                OnlineShopingBusiness bll = new OnlineShopingBusiness();
                bll.DeleteItemFromCart(id);
            }
            catch(OnlineShopingException ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return errRes;
        }

        /// <summary>
        /// This method is used to update 
        /// </summary>the dabase quantity
        /// <param name="cartList"></param>
        /// <param name="id"></param>
        [Route("api/OnlineShopingWeb/PutItemsById/{id}")]
        public void PutItemsById([FromBody] CartItems cartList, int id)
        {
            OnlineShopingBusiness bll = new OnlineShopingBusiness();
            bll.UpdateItemsById(cartList);
        }

        /// <summary>
        /// This method is used to get product by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>product details</returns>
        [Route("api/OnlineShopingWeb/GetProductItemById/{id}")]
        public CartItems GetProductItemById(int id)
        {
            OnlineShopingBusiness bll = new OnlineShopingBusiness();
            var lst = bll.GetProductItemById(id);
            return lst;
        }

    }
}