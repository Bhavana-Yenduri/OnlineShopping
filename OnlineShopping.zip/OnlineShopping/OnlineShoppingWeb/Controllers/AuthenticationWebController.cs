﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShopingBusinessLayer;
using OnlineShopingEntityLayer;
using OnlineShopingExceptionLayer;

namespace OnlineShoppingWeb.Controllers
{
    public class AuthenticationWebController : ApiController
    {
        /// <summary>
        /// The method is used to retrieve username from database
        /// </summary>
        /// <param name="name"></param>
        /// <returns>username</returns>
        [Route("api/AuthenticationWeb/GetUserName/{name}")]
        public Login_Details GetUserName(string name)
        {
            OnlineShopingBusiness bll = new OnlineShopingBusiness();
            var username = bll.GetUserName(name);
            return username;
        }
        /// <summary>
        /// This method is used to retrieve password from database
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns>password</returns>
        [Route("api/AuthenticationWeb/GetPassword/{pwd}")]
        public Login_Details GetPassword(string pwd)
        {
            OnlineShopingBusiness bll = new OnlineShopingBusiness();
            var password = bll.GetPassword(pwd);
            return password;
        }
    }
}
