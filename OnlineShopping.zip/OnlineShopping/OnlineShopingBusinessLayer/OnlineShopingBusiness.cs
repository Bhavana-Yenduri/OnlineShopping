﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShopingDataAccessLayer;
using OnlineShopingEntityLayer;
using OnlineShopingExceptionLayer;

namespace OnlineShopingBusinessLayer
{
    public class OnlineShopingBusiness:IBusiness
    {
        /// <summary>
        /// This method retrieves list of products based on product name
        /// </summary>
        /// <param name="productName"></param>
        /// <returns>list of products</returns>
        public List<Product> GetProductsByName(string productName)
        {
            //try block to throw when exception occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var lst = dal.GetProductsByName(productName);
                return lst;
            }
            //handles when exception occurs
            catch(OnlineShopingException ex)
            {
                throw ex;
            }
           
        }


        /// <summary>
        /// This method retrieves list of products based on category name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>List of products</returns>
        public List<Product> GetProductsByCategory(string Name)
        {
            //try block throws when exception occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var lst = dal.GetProductsByCategory(Name);
                return lst;
            }
            //handles when exception occurs
            catch(OnlineShopingException ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method retrieves all categories
        /// </summary>
        /// <returns>All Categories</returns>
        public List<Category> GetAllCategories()
        {
            //try block throws exception when it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var lst = dal.GetAllCategories();
                return lst;
            }
            //handles the exception when it occurs
            catch(OnlineShopingException ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method retrieves product details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Product details</returns>
        public Product GetProductDetailsById(int id)
        {
            //try block throws the exception when it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var pro = dal.GetProductDetailsById(id);
                return pro;
            }
            //handles the thrown exception
            catch(OnlineShopingException ex)
            {
                throw ex;
            }
            
        }


        /// <summary>
        /// This methods post product details to database
        /// </summary>
        /// <param name="cartList"></param>
        public void AddToCart(List<CartItems> cartList)
        {
            //try block throws exception when it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                dal.AddToCart(cartList);
            }
            //handles the thrown exception
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method retrieves the cart list from database
        /// </summary>
        /// <returns>List of products in Cart</returns>
        public List<CartItems> GetListFromCart()
        {
            //try block throws the exception when it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var pro = dal.GetListFromCart();
                return pro;
            }
            //handles the exception
            catch(OnlineShopingException e)
            {
                throw e;
            }
            catch(Exception e)
            {
                throw e;
            }
        }


        /// <summary>
        /// This method deletes the product from cart
        /// </summary>
        /// <param name="id"></param>
        public void DeleteItemFromCart(int id)
        {
            //try block throws the exception
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                dal.DeleteItemFromCart(id);
            }
            //handles the thrown exception
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method updates the product 
        /// </summary>
        /// <param name="cartList"></param>
        public void UpdateItemsById(CartItems cartList)
        {
            //try block throws the exception when it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                dal.UpdateItemsById(cartList);
            }
            //handles the thrown exception when occurs
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method retrieve the product from cart using id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Product details from cart</returns>
        public CartItems GetProductItemById(int id)
        {
            //try block throws an exception if it occurs
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var product = dal.GetProductItemById(id);
                return product;
            }
            //handles the thrown exception when occurs
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            
        }

        /// <summary>
        /// This method retrieve the username from the database
        /// </summary>
        /// <param name="uname">username is password</param>
        /// <returns>Username from database</returns>
        public Login_Details GetUserName(string uname)
        {
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var username = dal.GetUserName(uname);
                return username;
            }
            catch(OnlineShopingException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method retrieve the password from the database
        /// </summary>
        /// <param name="pwd">password is passed</param>
        /// <returns>Password from database</returns>
        public Login_Details GetPassword(string pwd)
        {
            try
            {
                OnlineShopingDataAccess dal = new OnlineShopingDataAccess();
                var password = dal.GetPassword(pwd);
                return password;
            }
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
        }


    }
}


