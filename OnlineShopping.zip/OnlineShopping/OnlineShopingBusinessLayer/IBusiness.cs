﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShopingEntityLayer;//for using onlineshopping entity library

namespace OnlineShopingBusinessLayer
{
    /// <summary>
    /// Interface for Online Shoping Business Layer
    /// </summary>

    interface IBusiness
    {
        /// <summary>
        /// This method will retrieve products based on name of the product
        /// </summary>
        /// <param name="productName"></param>
        /// <returns>List of Products from database</returns>
        List<Product> GetProductsByName(string productName);


        /// <summary>
        /// This method will retrieve products based on category of the product
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>List of products from database</returns>
        List<Product> GetProductsByCategory(string Name);


        /// <summary>
        /// This method will retrieve all categories and displays on home page
        /// </summary>
        /// <returns>List of categories from database</returns>
        List<Category> GetAllCategories();


        /// <summary>
        /// This method will retrieve product details based on product id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Product details from database</returns>
        Product GetProductDetailsById(int id);


        /// <summary>
        /// This method stores the products list into database
        /// </summary>
        /// <param name="cartList">Product details in the cart are passed</param>
        void AddToCart(List<CartItems> cartList);


        /// <summary>
        /// This method retrieves products from database
        /// </summary>
        /// <returns>List of products</returns>
        List<CartItems> GetListFromCart();


        /// <summary>
        /// This method deletes item from database based on id
        /// </summary>
        /// <param name="id">Product id is passed</param>
        void DeleteItemFromCart(int id);


        /// <summary>
        /// This method Updates product details in database
        /// </summary>
        /// <param name="cartList">cart List is passed</param>
        void UpdateItemsById(CartItems cartList);


        /// <summary>
        /// This method will retrieve product item based on id from database
        /// </summary>
        /// <param name="id">Product Id is passed</param>
        /// <returns>product details</returns>
        CartItems GetProductItemById(int id);


        /// <summary>
        /// This method will retrieve the username from database
        /// </summary>
        /// <param name="uname">username is passed by the user</param>
        /// <returns>username</returns>
        Login_Details GetUserName(string uname);

        /// <summary>
        /// This method will retrieve the password from the database
        /// </summary>
        /// <param name="pwd">password is passed as parameter</param>
        /// <returns>password from the database</returns>
        Login_Details GetPassword(string pwd);

    }
}
