﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShopingEntityLayer;//for using entity library
using System.Data;
using System.Data.SqlClient;
using OnlineShopingExceptionLayer;//for accessing the exception library
using System.Configuration;

namespace OnlineShopingDataAccessLayer
{
    public class OnlineShopingDataAccess : IDataAccess
    {
        SqlConnection con;
        SqlCommand cmd;
        /// <summary>
        /// This method holds the sql connection string 
        /// </summary>
        public OnlineShopingDataAccess()
        {
            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }


        /// <summary>
        /// This method will retrieve products based on name of the product
        /// </summary>
        /// <param name="productName"></param>
        /// <returns>List of Products from database</returns>
        public List<Product> GetProductsByName(string productName)
        {
            //creates object of type list for product entity class
            List<Product> products = new List<Product>();
            //try block, incase if code throws an exception
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                //Query for selecting the required columns from product table in database
                cmd.CommandText = "select id,pname,picture,price,description from product where pname like @name";
                //initially clears all the garbage values
                cmd.Parameters.Clear();
                //
                cmd.Parameters.AddWithValue("@name", "%" + productName + "%");
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Product pro = new Product
                    {
                        ProductId = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        Description = sdr[4].ToString()
                    };
                    //adding to product
                    products.Add(pro);
                }
                //closing the data reader connection
                sdr.Close();
            }
            //if sqlexception occurs, this catch block will handle it
            catch(SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //if any other exception occurs, this block will handle
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //the finally block executes eventhough the exception occurs or not occurs
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns the list of products
            return products;
        }


        /// <summary>
        /// This method will retrieve products based on category of the product
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>List of products from database</returns>
        public List<Product> GetProductsByCategory(string Name)
        {
            //creates object of type list for product entity class
            List<Product> products = new List<Product>();
            //try block, incase if code throws an exception
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                //Query for selecting the required columns from product table in database
                cmd.CommandText = "select p.id,p.pname,p.picture,p.price from product as p join prod_category as c " +
                                    " on p.categoryid=c.categoryid and c.categoryname like @cn";
                //initially clears all the garbage values
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@cn", "%" + Name + "%");
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Product pro = new Product
                    {
                        ProductId = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    //adding to product
                    products.Add(pro);
                }
                //sql data reader connection closed
                sdr.Close();
            }
            //if sql exception occurs,this block handles the exception
            catch(SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //if any other exception occurs, this block will handle
            catch(Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //this finally block executes whether exception occurs or not occurs
            finally
            {
                con.Close();
            }  
            //returns the list of the products
            return products;
        }


        /// <summary>
        /// This method will retrieve all categories and displays on home page
        /// </summary>
        /// <returns>List of categories from database</returns>
        public List<Category> GetAllCategories()
        {
            //creates object of type list for category entity class
            List<Category> lstCategorys = new List<Category>();
            //try block incase if code throws an exception
            try
            {
                //configure SELECT command
                cmd = new SqlCommand();
                //Query for selecting columns and retrieving from database
                cmd.CommandText = "select categoryid,categoryname from prod_category";
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //reads the record from sql data reader and add them to the collection
                while (sdr.Read())
                {
                    Category cat = new Category
                    {
                        CategoryId = (int)sdr[0],
                        CategoryName = sdr[1].ToString()
                    };
                    //adding to categoryList
                    lstCategorys.Add(cat);
                }
                //closing the data reader connection
                sdr.Close();
            }
            //if sql exception occurs,it will handle here
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //if any other exception occurs, it will handle here
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //this finally block executes whether exception ocuurs or not occurs
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns categories list
            return lstCategorys;
        }


        /// <summary>
        /// This method will retrieve product details based on product id
        /// </summary>
        /// <param name="id">product id is passed</param>
        /// <returns>Product details from database</returns>
        public Product GetProductDetailsById(int id)
        {
            //creates object of type list for product entity class
            Product pro = null;
            //try block, incase if code throws an exception
            try
            {
                //
                cmd = new SqlCommand();
                //Query for selecting the required columns from product table in database
                cmd.CommandText = "select id,pname,picture,description,price,Quantity from product where id=@id";
                //initially clears all the garbage values
                cmd.Parameters.Clear();
                //adding parameters 
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = System.Data.CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //read the records from data reader and add them to the collection
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    pro = new Product();
                    pro.ProductId = (int)sdr[0];
                    pro.ProductName = sdr[1].ToString();
                    pro.Picture = sdr[2].ToString();
                    pro.Description = sdr[3].ToString();
                    pro.Price = Convert.ToDouble(sdr[4]);
                    pro.Quantity = (int)sdr[5];
                }
                else
                {
                    throw new Exception("Product does not exist");
                }
            }
            //if Online Shoping Exception occurs, this block will handle it
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            //if sqlexception occurs, this catch block will handle it
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //if any other exception occurs, this block will handle
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //the finally block executes eventhough the exception occurs or not occurs
            finally
            {
                //closing the connection
                con.Close();
            }
            //return product details
            return pro;
        }


        /// <summary>
        /// This method stores the products list into database
        /// </summary>
        /// <param name="cartList">Product details in the cart are passed</param>
        public void AddToCart(List<CartItems> cartList)
        {
            //intialize roweffected variable
            int roweffected;
            //try block, incase if code throws an exception
            try
            {
                //open connection
                con.Open();
                //foreach loop for displaying the list in cart
                foreach (var items in cartList)
                {
                    //configure command for SELECT statement
                    cmd = new SqlCommand();
                    //Query for inserting the product details into database 
                    cmd.CommandText = "insert into cartItems(id,pname,picture,price,description,Quantity) values(@id,@pn,@pic,@pr,@des,@Qty)";
                    //Removes the garbage values
                    cmd.Parameters.Clear();
                    //add the values to the cart items 
                    cmd.Parameters.AddWithValue("@id", items.ProductId);
                    cmd.Parameters.AddWithValue("@pn", items.ProductName);
                    cmd.Parameters.AddWithValue("@pic", items.Picture);
                    cmd.Parameters.AddWithValue("@pr", items.Price);
                    cmd.Parameters.AddWithValue("@des", items.Description);
                    cmd.Parameters.AddWithValue("@Qty", items.Quantity);                    
                    cmd.CommandType = System.Data.CommandType.Text;
                    //configure connection
                    cmd.Connection = con;
                    //executes the non Query
                    roweffected = cmd.ExecuteNonQuery();
                    //if condition is true data can not be inserted
                    if(roweffected==0)
                    {
                        //throws exception
                        throw new Exception("could not add data");
                    }
                }
            }
            //if sqlexception occurs then this blocks handles the exception
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //if any other exception occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //finally block executes even exception occurs or not occurs
            finally
            {
                //closing the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method retrieves the Products that are added to the cart
        /// </summary>
        /// <returns>The List of products from CartItems Table</returns>
        public List<CartItems> GetListFromCart()
        {
            // creates object of type list for product entity class
             List<CartItems> lst = new List<CartItems>();
            //try block throws the exception when it occurs
            try
            {
                //configuring the SELECT command
                cmd = new SqlCommand();
                //Query for retrieving the required data
                cmd.CommandText = "select id,pname,picture,price,description from cartItems";
                cmd.CommandType = CommandType.Text;
                //attaching the connection
                cmd.Connection = con;
                //opening connection
                con.Open();
                //configuring the sql reader 
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    CartItems cart = new CartItems
                    {
                        ProductId=(int)sdr[0],
                        ProductName=sdr[1].ToString(),
                        Picture=sdr[2].ToString(),
                        Price=Convert.ToDouble(sdr[3]),
                        Description=sdr[4].ToString()
                    };
                    lst.Add(cart);
                }
                //closing the  data reader 
                sdr.Close();
            }
            //handles when the sql exception occurs
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //handles when any other exception occurs
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //executes finally 
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of products
            return lst;
        }


        /// <summary>
        /// This method deletes item from database based on id
        /// </summary>
        /// <param name="id">Product id is passed</param>
        public void DeleteItemFromCart(int id)
        {
            //try block, incase if code throws an exception
            try
            {
                //Configuring the DELETE Command
                cmd = new SqlCommand();
                //Query For deleting the unwanted product from the cart
                cmd.CommandText = "delete from cartItems where id=@id";
                //Clears the garbage values
                cmd.Parameters.Clear();
                //Parameters to add the value for the record of deletion
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = CommandType.Text;
                //attaching the connection
                cmd.Connection = con;
                //opening the connection
                con.Open();
                //executing the Query
                int recordsAffected = cmd.ExecuteNonQuery();
                //Closing the connection
                con.Close();
                //if condition is true then it throws the exception
                if (recordsAffected == 0)
                {
                    //throws an exception with a message
                    throw new Exception("could not delete");
                }
            }
            //handles the exception when sql exception occurs
            catch(SqlException e)
            {
                throw new OnlineShopingException(e.Message);
            }
            //handles the exception when any other exception occurs
            catch (Exception e)
            {
                throw new OnlineShopingException(e.Message);
            }
            //executes anyways even when exception occurs or not 
            finally
            {
                //closing the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method Updates product details in database
        /// </summary>
        /// <param name="cartList">cart List is passed</param>
        public void UpdateItemsById(CartItems cartList)
        {
            //try block, incase if code throws an exception
            try
            {
                //configuring sql Update Command
                cmd = new SqlCommand();
                //Query for updating the database
                cmd.CommandText = "update cartItems set Quantity=@qty where id=@id";
                //attaching the connection
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                //clears the garbage values
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", cartList.ProductId);
                cmd.Parameters.AddWithValue("@qty", cartList.Quantity);
                //opening the connection
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                //closing the connection
                con.Close();
                if (recordsAffected == 0)
                {
                    throw new Exception("id does not exist");
                }
            }
            //handles when the sql exception occurs
            catch (SqlException e)
            {
                throw new OnlineShopingException(e.Message);
            }
            //handles when anyother exception occurs 
            catch (Exception e)
            {
                throw new OnlineShopingException(e.Message);
            }
            //executes eventhough exception ocuurs or not occurs
            finally
            {
                con.Close();
            }

        }


        /// <summary>
        /// This method will retrieve product item based on id from database
        /// </summary>
        /// <param name="id">Product Id is passed</param>
        /// <returns>product details</returns>
        public CartItems GetProductItemById(int id)
        {
            CartItems cartList = null;
            //used to throw the exception when it occurs
            try
            {
                //configuring sql SELECT command
                cmd = new SqlCommand();
                //Query to retrieve required values from the database
                cmd.CommandText = "select id,pname,picture,price,description,Quantity from cartItems where id=@id";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = System.Data.CommandType.Text;
                //attaching the connection
                cmd.Connection = con;
                //opening connection
                con.Open();
                //configuring data reader connection
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    cartList = new CartItems();
                    cartList.ProductId = (int)sdr[0];
                    cartList.ProductName = sdr[1].ToString();
                    cartList.Picture = sdr[2].ToString();
                    cartList.Price = Convert.ToDouble(sdr[3]);
                    cartList.Description = sdr[4].ToString();
                    cartList.Quantity = (int)sdr[5];
                }
                else
                {
                    throw new Exception("Product does not exist");
                }
                //closing data reader
                sdr.Close();
            }
            //handles when onlineshopingexception occurs
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            //handles when sql exception occurs
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //handles when any other exception occurs
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //excutes at last whether exception occur or not occurs
            finally
            {
                con.Close();
            }
            //returns the list
            return cartList;
        }


        /// <summary>
        /// This method returns the username from the database
        /// </summary>
        /// <param name="uname">Username is passed</param>
        /// <returns>username</returns>
        public Login_Details GetUserName(string uname)
        {
            Login_Details login = new Login_Details();
            try
            {

                //configuring sql SELECT command
                cmd = new SqlCommand();
                //Query to retrieve required values from the database
                cmd.CommandText = "select username from login_details where username=@un";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", uname);
                cmd.CommandType = System.Data.CommandType.Text;
                //attaching the connection
                cmd.Connection = con;
                //opening connection
                con.Open();
                //configuring data reader connection
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.UserName = sdr[0].ToString();
                }
                //closing data reader
                sdr.Close();
            }
            //handles when onlineshopingexception occurs
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            //handles when sql exception occurs
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //handles when any other exception occurs
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //excutes at last whether exception occur or not occurs
            finally
            {
                con.Close();
            }
            //returns the list
            return login;
        }


        /// <summary>
        /// This method returns the password from the database
        /// </summary>
        /// <param name="pwd">password is passed</param>
        /// <returns>password from database</returns>
        public Login_Details GetPassword(string pwd)
        {
            Login_Details login = new Login_Details();
            try
            {

                //configuring sql SELECT command
                cmd = new SqlCommand();
                //Query to retrieve required values from the database
                cmd.CommandText = "select password from login_details where password=@pd";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@pd", pwd);
                cmd.CommandType = System.Data.CommandType.Text;
                //attaching the connection
                cmd.Connection = con;
                //opening connection
                con.Open();
                //configuring data reader connection
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.Password = sdr[0].ToString();
                }
                //closing data reader
                sdr.Close();
            }
            //handles when onlineshopingexception occurs
            catch (OnlineShopingException ex)
            {
                throw ex;
            }
            //handles when sql exception occurs
            catch (SqlException ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //handles when any other exception occurs
            catch (Exception ex)
            {
                throw new OnlineShopingException(ex.Message);
            }
            //excutes at last whether exception occur or not occurs
            finally
            {
                con.Close();
            }
            //returns the list
            return login;
        }
    }
}
